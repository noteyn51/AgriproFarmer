require('./build/scripts/ng-map.js');
module.exports = 'ngMap';